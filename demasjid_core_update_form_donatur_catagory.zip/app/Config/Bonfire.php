<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Bonfire extends BaseConfig
{
    public $views = [
        'filter_list' => 'App\Views\_filter_list',
    ];
}

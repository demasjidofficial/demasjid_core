<?php

namespace App\Modules\Api\Models;

class RegisterModel extends PendaftaranModel
{	
	protected $beforeInsert = [];
}

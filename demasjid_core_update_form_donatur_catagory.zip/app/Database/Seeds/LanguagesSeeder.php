<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class LanguagesSeeder extends Seeder
{
	/*
    public function run()
    {
        $sql = <<<'SQL'
                    INSERT INTO languages (`code`,`name`,`state`,`is_default`) VALUES
            	 	('id','Indonesia','Inactive',1),
            	 	('sa','Arabic','Inactive',0),
				 	('en','English','Inactive',0)
            SQL;

        $this->db->query($sql);
    }
	*/
}
